# Batch 1 — Marketing / www.strefex.pro (bugfix rebuild)
Built: 20260902-1140

## Why this rebuild
Previous Batch 1 could blank the homepage for many users:
1. `MarketingHome` used `iframe src` while production had `X-Frame-Options: DENY` / `frame-ancestors 'none'`.
2. SPA rewrite swallowed `/marketing-site/*` so assets never served.
3. `site.js` was referenced by `index.html` but missing from the zip.

## Includes (connected set)
- `public/marketing-site/**` — HTML, `site.js`, i18n, assets
- `src/pages/marketing/**` — srcDoc `MarketingHome` + shell/intro/CSS
- `vercel.json` — exclude `marketing-site` from SPA rewrite; SAMEORIGIN framing
- `public/sw.js` — cache bump so clients drop stale shells
- `Register.jsx` — `?type=` deep-links
- `App.jsx` + `lazyPages.js` — `/` → MarketingShell

## Deploy
1. Overlay these files onto the release tree.
2. `npm run build` (Vite copies `public/marketing-site` → `dist/marketing-site`).
3. Deploy `dist` + ensure host uses this `vercel.json` (or equivalent nginx rules).
4. Smoke-test `/`, `/marketing-site/index.html`, `/marketing-site/site.js`, `/register?type=buyer`.

## Notes
If also shipping Batch 2, apply Batch 1 first, then Batch 2, and resolve `App.jsx` / `lazyPages.js` once (prefer the union).
